#define BOARD_DUE
//#define WIREFRAME

void tft_setup();
void tft_loop();
void showParam();
