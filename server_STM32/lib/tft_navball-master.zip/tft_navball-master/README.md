# tft_navball
Kerbal Space Program LCD Navball for Arduino Mega

Uses zitronen's KSPSerialIO to interface with KSP and Bodmer's TFT_HX8357 to interface with the LCD.

Mega drives 320x480 colour LCD at 10 frames per second, and DUE gets about 15.

